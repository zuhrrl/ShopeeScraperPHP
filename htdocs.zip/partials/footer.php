<footer class="bg-gray-200">
    <div class="container mx-auto px-6 py-3 flex justify-between items-center">
        <a href="#" class="text-xl font-bold text-gray-500 hover:text-gray-400">Kaosqu</a>
        <p class="py-2 text-gray-500 sm:py-0">All rights reserved</p>
    </div>
</footer>
</div>
<script src="../assets/javascripts/alpine.min.js" defer></script>
<script src="../assets/javascripts/jquery.min.js"></script>
<script src="../assets/javascripts/app.js"></script>